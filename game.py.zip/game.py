import random


def print_board(board):
    print(
        f"""
    |---|---|---|
    | {board[0]} | {board[1]} | {board[2]} |
    |---|---|---|
    | {board[3]} | {board[4]} | {board[5]} |
    |---|---|---|
    | {board[6]} | {board[7]} | {board[8]} |
    |---|---|---|
"""
    )


def checkPlayerWin(board):
    # 가로 승리 조건
    if board[0] == "o" and board[1] == "o" and board[2] == "o":
        return True
    elif board[3] == "o" and board[4] == "o" and board[5] == "o":
        return True
    elif board[6] == "o" and board[7] == "o" and board[8] == "o":
        return True
    # 세로 승리 조건
    elif board[0] == "o" and board[3] == "o" and board[6] == "o":
        return True
    elif board[1] == "o" and board[4] == "o" and board[7] == "o":
        return True
    elif board[2] == "o" and board[5] == "o" and board[8] == "o":
        return True
    # 대각 승리 조건
    elif board[0] == "o" and board[4] == "o" and board[8] == "o":
        return True
    elif board[2] == "o" and board[4] == "o" and board[6] == "o":
        return True
    return False


def checkComputerWin(board):
    # 가로 승리 조건
    if board[0] == "x" and board[1] == "x" and board[2] == "x":
        return True
    elif board[3] == "x" and board[4] == "x" and board[5] == "x":
        return True
    elif board[6] == "x" and board[7] == "x" and board[8] == "x":
        return True
    # 세로 승리 조건
    elif board[0] == "x" and board[3] == "x" and board[6] == "x":
        return True
    elif board[1] == "x" and board[4] == "x" and board[7] == "x":
        return True
    elif board[2] == "x" and board[5] == "x" and board[8] == "x":
        return True
    # 대각 승리 조건
    elif board[0] == "x" and board[4] == "x" and board[8] == "x":
        return True
    elif board[2] == "x" and board[4] == "x" and board[6] == "x":
        return True
    return False


board = [" "] * 9

while True:
    print_board(board)
    position = int(input("위치를 입력하세요 (1 - 9) 종료는 0 입력: "))

    if board[position - 1] == "o" or board[position - 1] == "x":
        print("해당 위치에는 둘 수 없습니다.")
        continue

    if position == 0:
        print("게임을 종료합니다.")
        break

    board[position - 1] = "o"

    while True:
        computerPosition = random.randint(0, 8)
        if board[computerPosition] == " ":
            board[computerPosition] = "x"
            break

    if checkPlayerWin(board):
        print_board(board)  # 승리했을 때만 보드판 출력
        print("플레이어 승리")
        break
    elif checkComputerWin(board):
        print_board(board)
        print("컴퓨터 승리")
        break
    else:
        print_board(board)
        print("무승부")
